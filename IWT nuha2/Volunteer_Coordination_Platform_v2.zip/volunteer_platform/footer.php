</main>
<footer class="footer">
  <p>&copy; <?php echo date('Y'); ?> Volunteer Coordination Platform</p>
</footer>
</body>
</html>
